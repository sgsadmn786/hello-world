ebooklib Package
================

:mod:`ebooklib` Package
-----------------------

.. automodule:: ebooklib
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`epub` Module
------------------

.. automodule:: ebooklib.epub
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`utils` Module
-------------------

.. automodule:: ebooklib.utils
    :members:
    :undoc-members:
    :show-inheritance:

Subpackages
-----------

.. toctree::

    ebooklib.plugins

