plugins Package
===============

:mod:`base` Module
------------------

.. automodule:: ebooklib.plugins.base
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`booktype` Module
----------------------

.. automodule:: ebooklib.plugins.booktype
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`sourcecode` Module
------------------------

.. automodule:: ebooklib.plugins.sourcecode
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`standard` Module
----------------------

.. automodule:: ebooklib.plugins.standard
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`tidyhtml` Module
----------------------

.. automodule:: ebooklib.plugins.tidyhtml
    :members:
    :undoc-members:
    :show-inheritance:

