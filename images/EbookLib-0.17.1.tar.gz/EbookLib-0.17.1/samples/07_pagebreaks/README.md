Advanced create
===============

Create simple EPUB3 with both visible and invisible pagebreaks

## Start

    python create.py
