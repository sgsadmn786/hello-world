Plugins
=======

How to parse EPUB file.

## Start

    python parse.py my-book.epub
