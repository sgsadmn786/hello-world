__version__ = '1.2.1'
__VERSION__ = __version__
from .workbook import Workbook
